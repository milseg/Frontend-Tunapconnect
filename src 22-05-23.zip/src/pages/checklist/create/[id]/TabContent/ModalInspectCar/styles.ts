import styled from '@emotion/styled'
import ButtonBase from '@mui/material/ButtonBase'
import { Box, Button, Stack, Tabs, TextField, Typography } from '@mui/material'
import FileUploadOutlinedIcon from '@mui/icons-material/FileUploadOutlined'
import CloseOutlinedIcon from '@mui/icons-material/CloseOutlined'

interface LabelButtonMarkupTypeProps {
  selectedActual: boolean
}

interface ClickableAreaProps {
  urlImg: string
}
// interface ButtonMarkupProps {
//   topmarkup: number
//   leftmarkup: number
// }
// interface ButtonMarkupProps {
//   mobile: {
//     top: number
//     left: number
//   }
//   web: {
//     top: number
//     left: number
//   }
// }

export const TabsContainer = styled(Tabs)(({ theme }) => ({
  color: 'black',
  fontWeight: 'bold',
  background: '#d5d5d5',
  // borderTopRightRadius: 0,
  // borderBottomRightRadius: 0,
  // padding: '5px 16px',
  textTransform: 'none',
  '& .Mui-selected': {
    background: '#93BE0F',
    color: '#FFFFFF',
  },
  '& .MuiTabs-indicator': {
    backgroundColor: '#ffffff',
  },
}))

export const LabelButtonMarkupType = styled('label')(({ theme }) => ({
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  justifyContent: 'center',
  gap: '5px',
  '& > span': {
    fontWeight: 'bold',
    textTransform: 'uppercase',
    fontSize: '12px',
  },
  '&:hover': {
    cursor: 'pointer',
  },
}))

export const ButtonMarkupType = styled.button<LabelButtonMarkupTypeProps>`
  color: #707070;
  background: rgb(237, 234, 234, 0.7);
  width: 44px;
  height: 44px;
  font-size: 25px;
  text-transform: uppercase;

  display: flex;
  align-items: center;
  justify-content: center;

  line-height: 25px;
  border: 3px solid ${(props) => (props.selectedActual ? '#93BE0F' : '#1acaba')};

  border-radius: 50%;
  padding: 0;
  &:hover {
    background: ${(props) => (props.selectedActual ? '#93BE0F' : '#1acaba')};
    color: #fff;
    cursor: pointer;
  }
`

export const ButtonMarkup = styled(ButtonBase)`
  color: #707070;
  background: rgba(237, 234, 234, 0.7);
  width: 44px;
  height: 44px;
  font-size: 25px;
  text-transform: uppercase;
  position: absolute;
  display: flex;
  align-items: center;
  justify-content: center;

  top: ${(props) => props?.web?.top};
  left: ${(props) => props?.web?.left};

  line-height: 25px;
  border: 3px solid #93be0f;

  border-radius: 50%;
  padding: 0;
  & > svg {
    display: none;
  }
  text-transform: none;
  &:hover {
    border: 3px solid #f26960;
    color: #f26960;
    & > svg {
      display: block;
    }
    & > span {
      display: none;
    }
    transition: all 0.3s ease-in-out;
  }

  /* @media (max-width: 768px) {
    top: ${(props) => props?.mobile?.top};
    left: ${(props) => props?.mobile?.left};
  } */
`
export const MyButton = styled(Button)(({ theme }) => ({
  color: 'white',
  background: '#0E948B',
  borderRadius: 4,
  // borderTopRightRadius: 0,
  // borderBottomRightRadius: 0,
  // padding: '5px 16px',
  flex: 1,
  textTransform: 'none',
  '&:hover': {
    background: '#1ACABA',
  },
}))
export const ButtonLeft = styled(Button)(({ theme }) => ({
  color: 'white',
  background: '#93BE0F',
  borderRadius: 0,
  borderTopLeftRadius: 6,
  borderBottomLeftRadius: 6,
  // padding: '5px 16px',
  flex: 1,
  textTransform: 'none',
  '&:hover': {
    background: '#1ACABA',
  },
}))
export const ButtonRight = styled(Button)(({ theme }) => ({
  color: 'white',
  background: '#93BE0F',
  borderRadius: 0,
  borderTopRightRadius: 6,
  borderBottomRightRadius: 6,
  // padding: '5px 16px',
  flex: 1,
  textTransform: 'none',
  '&:hover': {
    background: '#1ACABA',
  },
}))

export const ContainerInformation = styled(Stack)(({ theme }) => ({
  border: '1px solid #ACAAAA',
  borderRadius: 9,
  padding: 2,
  justifyContent: 'center',
}))
export const IconUpload = styled(FileUploadOutlinedIcon)(({ theme }) => ({
  fontSize: '16px',
}))
export const IconClose = styled(CloseOutlinedIcon)(({ theme }) => ({
  fontSize: '16px',
}))

export const Title = styled(Typography)(({ theme }) => ({
  fontSize: '10px',
  textTransform: 'uppercase',
  display: 'flex',
}))

export const TextAreaField = styled(TextField)(({ theme }) => ({
  '& .MuiOutlinedInput-root': {
    padding: 6,
    fontSize: 10,
  },
}))

export const ContainerClickableArea = styled(Box)`
  width: 490px;
  height: 350px;
  @media (max-width: 768px) {
    width: calc(490px - (490px * 0.3));
    height: calc(350px - (350px * 0.28));
    padding-bottom: 10px;
  }
`

export const ClickableArea = styled('img')<ClickableAreaProps>`
  /* width: 490px; */
  width: 100%;
  height: 350px;
  // background: 'red';
  // position: 'relative';
  border: 1px solid #acaaaa;
  border-radius: 9px;
  overflow: 'hidden';
  background-repeat: 'no-repeat';
  background-position: 'center';
  background-size: contain;
  background-image: url(${(props) => props.urlImg});
  '& *': {
    pointerevents: 'none';
  }

  @media (max-width: 768px) {
    width: 100%;
    height: 250px;
  }
`
