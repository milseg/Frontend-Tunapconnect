import { CircularProgress } from '@mui/material'

export function Loading() {
  return <CircularProgress />
}
